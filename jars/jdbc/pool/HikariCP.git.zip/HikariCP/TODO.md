### TODO ###

 * More unit tests
 * Add metrics support
