Example 4
=========

Overview:
=========
This example will demonstrate how job state can be maintained
and how parameters can be passed into jobs.


Running the Example:
====================
1. Windows users - Modify the example4.bat file (if necessary) 
to set your JAVA_HOME.  Run example4.bat

2. UNIX/Linux users - Modify the example4.sh file (if necessary)
to set your JAVA_HOME.  Execute example4.sh


Configuration Files:
====================
1.  You can decide to specify a log4j.properties file to
control logging output (optional)
