lz-string
=========
LZ-based compression algorithm for JavaScript

## Warning (migrating from version 1.3.4 - nov 2014)
Files have changed locations and name since a recent release. The new release file is in `libs/lz-string.min.js` (or in `libs/lz-string.js` if you don't care for the minified version)

Sorry about the mess in other repos. This will not happen again.

## Install via [npm](https://npmjs.org/)

```shell
$ npm install -g lz-string
$ lz-string input.js > output.txt
```

## Home page
Home page for this program with examples, documentation and a live demo: http://pieroxy.net/blog/pages/lz-string/index.html
