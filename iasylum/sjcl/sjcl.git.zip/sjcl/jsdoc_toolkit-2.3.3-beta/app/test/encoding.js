
/**
 * @Constructor
 * @desc 配置文件
 * @class 什么也不返回
 */
function Test(conf) {
    // do something;
}

