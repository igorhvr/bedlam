RewriteRequestHeaderFilter - a Java servlet filter for request header rewriting
===============================================================================

Demonstration servlet filter for performing request header rewrites according to
regex rules specified in the servlet init parameters.

It is packaged as a sample application (war/ear formats) and also a jar that can
be inserted into any arbitrary site.

Feel free to drop me a note at gallagher.paul@gmail.com if you have any queries or
problems with this.

References
----------
	For more discussion on "why?", and links to latest distribution, see:
		http://tardate.blogspot.com/2007/03/request-header-rewrites-with-java.html

	For more information on servlet filters, start parhaps with the
Sun article "The Essentials of Filters" http://java.sun.com/products/servlet/Filters.html 	


Distribution Contents
---------------------
RewriteRequestHeaderFilter-1.0-src.zip contains:
	readme.txt - this file
	build.xml - ant build script
	build.properties - environment-specific compiler properties
	web/index.jsp - sample page
	web/WEB-INF/web.xml - sample web deployment descriptor
	web/WEB-INF/src/com/urion/servletfilter/RewriteRequestHeaderFilter.java - filter source code
	META-INF/application.xml - deployment descriptor for EAR
	build/RewriteRequestHeaderFilter.ear - sample ear file, ready for deployment
	build/RewriteRequestHeaderFilter.jar - sample jar file, ready for deployment
	build/RewriteRequestHeaderFilter.war - sample war file, ready for deployment



How to Build
------------

You need Apache Ant and a JDK with servlet 2.3+

Step 1: Unzip the distribution kit into a new directory

Step 2: Locate the servlet.jar in your environment (not included in the distribution),
	and update the servlet.jar property in the build.properties file.

Step 3: Set your ant and java environment


Step 4: Build using ant. There are a number of targets possible.

	ant
		- with no parameter, it will run the "all" target to compile the source
		  and generate the jar, war and ear files

	ant clean
		- clean up your built files

	ant dist
		- as for "all", but also generates the distribution zip file

	See the build.xml for other finer-grained build/compile tasks


Deploying the sample site
-------------------------

Choose either the war or ear file, depending on yr preference and the J2EE container you
are running. Follow the container instructions for deploying a new web application.

As an example, here's how you can manually deploy to Oracle OC4J:

Manually deploy WAR version to OC4J:
1. Copy WAR to j2ee/home/applications

2. In j2ee/home/config/application.xml, add application definition:
	<web-module id="filtertest" path="../../home/applications/RewriteRequestHeaderFilter.war" />

3. In j2ee/home/config/http-web-site.xml, add web app definition:
	<web-app application="filtertest" name="filtertest" root="/filtertest" />

Manually deploy EAR version to OC4J:
1. Copy EAR to j2ee/home/applications

2. In j2ee/home/config/server.xml, add application definition:
	<application name="filtertest" path="../../home/applications/RewriteRequestHeaderFilter.ear" />

3. In j2ee/home/config/http-web-site.xml, add web app definition:
	<web-app application="filtertest" name="filtertest" root="/filtertest" />

Once you have deployed the application, go to http://localhost/filtertest (or whatever your server url is)
The sample inlcudes a simple rewrite definition in the web.xml that will change your HOST header from
"localhost" to "127.0.0.1". If you are not running on HOST=localhost, obviously you will need to change
the rewrite rules to see any effect.


Specifying Rewrite Rules
------------------------

Rewrite rules are coded in the init parameters for the filter in the web.xml file.

There are three things to be done in the web.xml:
1. Define the "filter"
2. Specify the rewrite rules with filter init-param
3. Define the "filter-mapping"

A sample web.xml extract is shown below, which also has inline documentation of the
rewrite rule format.

	<!-- Define the filters within the Web Application -->
	
	<filter>
		<filter-name>RewriteRequestHeaderFilter</filter-name>
		<filter-class>com.urion.servletfilter.RewriteRequestHeaderFilter</filter-class>

		<!-- 
		Define the header rewrite rules in init-params, where:
			param-name = header name
			param-value = rewrite rule

		Rewrite rules are encoded strings in two parts, separated by ####
			First part is the matching rule (regex allowed)
			Second part is the replacement string for a match
		-->

		<init-param>
			<param-name>HOST</param-name>
			<param-value>localhost####127.0.0.1</param-value>
		</init-param>
	</filter>
	
	
	<!-- Map the filter to a Servlet or URL -->
	
	<filter-mapping>
		<filter-name>RewriteRequestHeaderFilter</filter-name>
		<url-pattern>/*</url-pattern>
	</filter-mapping>



Deploying into an existing site
-------------------------------

If you have an existing web application that you wish to "insert" request header 
rewrites, you can modify the deployment in-situ.

Basically there are three steps.

Step 1: Copy the RewriteRequestHeaderFilter.jar to the WEB-INF/lib directory

Step 2: Modify the site's WEB-INF/web.xml
	- include the filter definition, rewrite rules and filter-mapping as 
	  described in the previous section

Step 3: Reload the site
	- check the app server console or log files for any errors if the rewriting is
	  not happening as expected.


