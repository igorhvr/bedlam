/* 
 *  Copyright (C) 2007, Paul Gallagher <gallagher.paul@gmail.com>.
 *  All rights reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  $Id: RewriteRequestHeaderFilter.java,v 1.1 2007/03/27 15:45:17 paulg Exp $
 */

package com.urion.servletfilter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.util.Enumeration;
import java.util.regex.*;

import java.io.IOException;
import javax.servlet.ServletException;

/**
 * Demonstration servlet filter that implements header generic rewriting.
 *
 * For more information about filters, see: http://java.sun.com/products/servlet/Filters.html
 *
 * @version $Id: RewriteRequestHeaderFilter.java,v 1.1 2007/03/27 15:45:17 paulg Exp $
 * @author 	Paul Gallagher
 */
public class RewriteRequestHeaderFilter implements Filter
{
	private FilterConfig filterConfig;
	
	public void init(FilterConfig filterConfig) 
		throws ServletException {
		this.filterConfig = filterConfig;
	}
	
	public void destroy() {
		this.filterConfig = null;
	}

	public void doFilter (ServletRequest request,
	         ServletResponse response,
	         FilterChain chain)
	{
		
		try
		{
			//System.out.println ("Within Simple Filter ... Filtering the Request ...");

			// wrap request with class that will perform the rewrite
			MyRequestWrapper myRequest = new MyRequestWrapper((HttpServletRequest)request, filterConfig );

			// demo passing an attribute
			myRequest.setAttribute("hello","Hello World! This was inserted by the RewriteRequestHeaderFilter.");

			chain.doFilter (myRequest, response);
						
		} catch (IOException io) {
			System.out.println ("IOException raised in RewriteRequestHeaderFilter");
		} catch (ServletException se) {
			System.out.println ("ServletException raised in RewriteRequestHeaderFilter");
		}
	}

	public FilterConfig getFilterConfig()
	{
		return this.filterConfig;
	}
	
	public void setFilterConfig (FilterConfig filterConfig)
	{
		this.filterConfig = filterConfig;
	}




class MyRequestWrapper extends HttpServletRequestWrapper {

	FilterConfig myFilterConfig;


	public MyRequestWrapper(HttpServletRequest request, FilterConfig filterConfig ){
		super(request);
		myFilterConfig = filterConfig;
	}

	public String getHeader(String name) {
		Enumeration initParams = myFilterConfig.getInitParameterNames();

		if (initParams == null) {
			// No elements to verify
			return super.getHeader(name);
		} else {
			String newHeader = super.getHeader(name);
			//System.out.print(name + " is=" + newHeader);
			try {
	
		        while (initParams.hasMoreElements())
		        {
					String paramName = (String) initParams.nextElement();
					if ( name.equalsIgnoreCase(paramName) ) {
						String[] filter = myFilterConfig.getInitParameter(paramName).split("####");
						if ( filter.length == 2 ) {
						    Pattern p = Pattern.compile(filter[0]);
	    					Matcher m = p.matcher(newHeader);
	    					newHeader = m.replaceAll(filter[1]);
						}
						break;
					}
				}
			} catch (Exception e) {
				System.out.println ("Exception raised in MyRequestWrapper");
				e.printStackTrace();
			}
			//System.out.println(" now=" + newHeader);
			return newHeader;

		}
	}

}


}

