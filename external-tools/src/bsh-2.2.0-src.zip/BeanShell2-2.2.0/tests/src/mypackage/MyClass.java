package mypackage;

public class MyClass {
	public MyClass() {
		System.out.println("MyClass constructor: bar");
	}
	public static void print( String s ) {
		System.out.println(s);
	}
}

