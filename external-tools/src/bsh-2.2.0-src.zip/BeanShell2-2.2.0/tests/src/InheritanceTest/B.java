package InheritanceTest;

public interface B extends A {
	void b();
}
