package bsh;

public class ProjectCoinFeature extends KnownIssue {

	// public static boolean IS_BELOW_JAVA_v7 = "1.7".compareTo(System.getProperty("java.version").substring(0,3)) < 0;

}
