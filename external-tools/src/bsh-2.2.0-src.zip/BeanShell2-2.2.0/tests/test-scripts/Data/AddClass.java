/**
	@author Pat Niemeyer
*/
public class AddClass
{
	public int getFive() { return 5; }
}
