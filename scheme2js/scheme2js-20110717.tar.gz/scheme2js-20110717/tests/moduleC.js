/*** META (define-macro (foo x) (string-append x "yyy")) */

/*** META ((export #t)) */
var XX;
